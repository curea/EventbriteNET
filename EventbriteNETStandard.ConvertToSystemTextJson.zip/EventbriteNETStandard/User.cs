﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;

namespace EventbriteNET
{
    /// <summary>
    /// Represents an Eventbrite User <see cref="https://developer.eventbrite.com/docs/user-object/"/>
    /// </summary>

    public class User : EventbriteObject
    {
        public User()
        {
            Emails = new List<EmailField>();
        }

        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("first_name")]
        public string FirstName { get; set; }
        [JsonPropertyName("last_name")]
        public string LastName { get; set; }
        [JsonPropertyName("emails")]
        public IList<EmailField> Emails { get; set; }
    }
}
