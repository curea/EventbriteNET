﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System;

namespace EventbriteNET
{
    /// <summary>
    /// Represents an Eventbrite Format <see cref="https://developer.eventbrite.com/docs/format-object/"/>
    /// </summary>
    public class Format : EventbriteObject
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("name_localized")]
        public string NameLocalized { get; set; }
        [JsonPropertyName("short_name")]
        public string ShortName { get; set; }
        [JsonPropertyName("short_name_localized")]
        public string ShortNameLocalized { get; set; }
    }
}
