﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;

namespace EventbriteNET
{
    /// <summary>
    /// Represents an Eventbrite Organizer <see cref="https://developer.eventbrite.com/docs/organizer-object/"/>
    /// </summary>
    public class Organizer : EventbriteObject
    {
        public Organizer()
        {
            Description = new MultipartTextField();
            Logo = new ImageField();
        }

        [JsonPropertyName("description")]
        public MultipartTextField Description { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("logo")]
        public ImageField Logo { get; set; }
        [JsonPropertyName("num_past_events")]
        public int NumPastEvents { get; set; }
        [JsonPropertyName("num_future_events")]
        public int NumFutureEvents { get; set; }
    }
}
