﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System;
using System.Net.Http;

namespace EventbriteNET.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="HttpClient"/> related calls
    /// </summary>
    public static class HttpExtensions
    {
        public static T As<T>(this HttpResponseMessage response)
        {
            if (response.Content != null)
            {
                var content = response.Content.ReadAsStringAsync().Result;
                return JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions
                {
                    NumberHandling = JsonNumberHandling.AllowReadingFromString
                });
            }
            else
                return default(T);
        }
    }
}
