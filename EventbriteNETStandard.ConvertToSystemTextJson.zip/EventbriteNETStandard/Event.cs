﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System;
using System.Collections.Generic;

namespace EventbriteNET
{
    /// <summary>
    /// Represents an Eventbrite Event <see cref="https://developer.eventbrite.com/docs/event-object/"/>
    /// </summary>
    public class Event : EventbriteObject
    {
        public Event()
        {
            Name = new MultipartTextField();
            Description = new MultipartTextField();
            Start = new DateTimeTimezoneField();
            End = new DateTimeTimezoneField();
            Created = DateTime.UtcNow;
            Changed = DateTime.UtcNow;
            Organizer = new Organizer();
            Venue = new Venue();
            Category = new Category();
            Subcategory = new Subcategory();
            TicketClasses = new List<TicketClass>();
        }

        [JsonPropertyName("name")]
        public MultipartTextField Name { get; set; }
        [JsonPropertyName("description")]
        public MultipartTextField Description { get; set; }
        [JsonPropertyName("url")]
        public string Url { get; set; }
        [JsonPropertyName("logo_url")]
        public string LogoUrl { get; set; }
        [JsonPropertyName("capacity")]
        public int Capacity { get; set; }
        [JsonPropertyName("status")]
        public StatusOptions Status { get; set; }
        [JsonPropertyName("currency")]
        public string Currency { get; set; }
        [JsonPropertyName("online_event")]
        public bool OnlineEvent { get; set; }
        [JsonPropertyName("start")]
        public DateTimeTimezoneField Start { get; set; }
        [JsonPropertyName("end")]
        public DateTimeTimezoneField End { get; set; }
        [JsonPropertyName("created")]
        public DateTime Created { get; set; }
        [JsonPropertyName("changed")]
        public DateTime Changed { get; set; }
        [JsonPropertyName("shareable")]
        public bool Shareable { get; set; }
        [JsonPropertyName("listed")]
        public bool Listed { get; set; }
        [JsonPropertyName("invite_only")]
        public bool InviteOnly { get; set; }
        [JsonPropertyName("show_remaining")]
        public bool ShowRemaining { get; set; }
        [JsonPropertyName("password")]
        public string Password { get; set; }

        [JsonPropertyName("organizer_id")]
        public long? OrganizerId { get; set; }
        [JsonPropertyName("venue_id")]
        public long? VenueId { get; set; }
        [JsonPropertyName("category_id")]
        public long? CategoryId { get; set; }
        [JsonPropertyName("subcategory_id")]
        public long? SubcategoryId { get; set; }
        [JsonPropertyName("format_id")]
        public long? FormatId { get; set; }

        [JsonPropertyName("organizer")]
        public Organizer Organizer { get; set; }
        [JsonPropertyName("venue")]
        public Venue Venue { get; set; }
        [JsonPropertyName("category")]
        public Category Category { get; set; }
        [JsonPropertyName("subcategory")]
        public Subcategory Subcategory { get; set; }
        [JsonPropertyName("format")]
        public Subcategory Format { get; set; }
        [JsonPropertyName("ticket_classes")]
        public IList<TicketClass> TicketClasses { get; set; }
    }

    public class PagedEvents : EventbriteObject
    {

        [JsonPropertyName("pagination")]
        public Pagination Pagination { get; set; }
        public List<Event> Events { get; set; }
    }
}
