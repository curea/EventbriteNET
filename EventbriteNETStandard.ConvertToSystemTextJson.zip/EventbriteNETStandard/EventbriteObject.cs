﻿using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace EventbriteNET
{
    /// <summary>
    /// Base Eventbrite Object <see cref="https://developer.eventbrite.com/docs/data-types/#object" />
    /// </summary>
    public abstract class EventbriteObject
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }
        [JsonPropertyName("resource_uri")]
        public string ResourceUri { get; set; }

    }

    public class Pagination
    {
        [JsonPropertyName("object_count")]
        public int ObjectCount { get; set; }
        [JsonPropertyName("page_number")]
        public int PageNumber { get; set; }
        [JsonPropertyName("page_size")]
        public int PageSize { get; set; }
        [JsonPropertyName("page_count")]
        public int PageCount { get; set; }

    }

   
}
