﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace EventbriteNET
{
    /// <summary>
    /// Represents an Eventbrite Venue <see cref="https://developer.eventbrite.com/docs/venue-object/"/>
    /// </summary>
    public class Venue : EventbriteObject
    {
        public Venue()
        {
            Address = new AddressField();
        }

        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("address")]
        public AddressField Address { get; set; }
        [JsonPropertyName("latitude")]
        public decimal Latitude { get; set; }
        [JsonPropertyName("longitude")]
        public string Longitude { get; set; }
    }
}
