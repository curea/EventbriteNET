﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System;

namespace EventbriteNET
{
    /// <summary>
    /// Represents an Eventbrite Ticket Class <see cref="https://developer.eventbrite.com/docs/ticket-class-object/"/>
    /// </summary>
    public class TicketClass : EventbriteObject
    {
        public TicketClass()
        {
            Cost = new CurrencyField();
            Fee = new CurrencyField();
        }

        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("description")]
        public string Description { get; set; }
        [JsonPropertyName("donation")]
        public bool Donation { get; set; }
        [JsonPropertyName("free")]
        public bool Free { get; set; }
        [JsonPropertyName("minimum_quantity")]
        public int? MinimumQuantity { get; set; }
        [JsonPropertyName("maximum_quantity")]
        public int? MaximumQuantity { get; set; }
        [JsonPropertyName("event_id")]
        public long EventId { get; set; }
        [JsonPropertyName("cost")]
        public CurrencyField Cost { get; set; }
        [JsonPropertyName("fee")]
        public CurrencyField Fee { get; set; }

        [JsonPropertyName("hidden")]
        public bool Hidden { get; set; }
        [JsonPropertyName("sales_start")]
        public DateTime? SalesStart { get; set; }
        [JsonPropertyName("sales_end")]
        public DateTime? SalesEnd { get; set; }
        [JsonPropertyName("sales_start_after")]
        public string SalesStartAfter { get; set; }
        [JsonPropertyName("quantity_total")]
        public int? QuantityTotal { get; set; }
        [JsonPropertyName("quantity_sold")]
        public int? QuantitySold { get; set; }
        [JsonPropertyName("include_fee")]
        public bool IncludeFee { get; set; }
        [JsonPropertyName("split_fee")]
        public bool SplitFee { get; set; }
        [JsonPropertyName("hide_description")]
        public bool HideDescription { get; set; }
        [JsonPropertyName("auto_hide")]
        public bool AutoHide { get; set; }
        [JsonPropertyName("auto_hide_before")]
        public DateTime? AutoHideBefore { get; set; }
        [JsonPropertyName("auto_hide_after")]
        public DateTime? AutoHideAfter { get; set; }
    }
}
