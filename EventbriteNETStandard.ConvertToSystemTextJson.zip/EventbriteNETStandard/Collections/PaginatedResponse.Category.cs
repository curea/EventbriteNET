﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;

namespace EventbriteNET.Collections
{
    public partial class PaginatedResponse<T> : IPaginatedResponse<T> where T : EventbriteObject
    {
        [JsonPropertyName("categories")]
        public IList<Category> Categories { get; set; }
    }
}
