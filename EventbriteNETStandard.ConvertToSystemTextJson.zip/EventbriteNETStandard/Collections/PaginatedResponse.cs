﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace EventbriteNET.Collections
{
    public partial class PaginatedResponse<T> : IPaginatedResponse<T> where T : EventbriteObject
    {
        public PaginatedResponse()
        {
            Pagination = new Pagination();
        }

        public PaginatedResponse(string dataName) : this()
        {
            this.DataName = dataName;

            // set Attribute name
            var dataJsonProperty = this.GetType().GetRuntimeProperty("Data").GetCustomAttribute<JsonPropertyNameAttribute>(true);
            //TODO: ABC - Needed?
            //dataJsonProperty.Name = this.DataName;
        }

        [JsonPropertyName("locale")]
        public string Locale { get; set; }
        [JsonPropertyName("pagination")]
        public Pagination Pagination { get; set; }
        [JsonPropertyName("data")]
        public IList<T> Data { get; set; }

        public string DataName { get; private set; }

        public bool HasPreviousPage
        {
            get { return (Pagination.PageNumber > 0); }
        }
        public bool HasNextPage
        {
            get { return (Pagination.PageNumber < Pagination.PageCount); }
        }
    }

    public class Pagination
    {
        [JsonPropertyName("object_count")]
        public int ObjectCount { get; set; }
        [JsonPropertyName("page_number")]
        public int PageNumber { get; set; }
        [JsonPropertyName("page_size")]
        public int PageSize { get; set; }
        [JsonPropertyName("page_count")]
        public int PageCount { get; set; }
    }
}
