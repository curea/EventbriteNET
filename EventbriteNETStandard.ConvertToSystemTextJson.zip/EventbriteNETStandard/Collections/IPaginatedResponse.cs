﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;

namespace EventbriteNET.Collections
{
    public interface IPaginatedResponse<T> where T : EventbriteObject
    {
        [JsonPropertyName("locale")]
        string Locale { get; set; }
        [JsonPropertyName("pagination")]
        Pagination Pagination { get; set; }
        [JsonPropertyName("data")]
        IList<T> Data { get; set; }

        string DataName { get; }
        bool HasPreviousPage { get; }
        bool HasNextPage { get; }
    }
}
