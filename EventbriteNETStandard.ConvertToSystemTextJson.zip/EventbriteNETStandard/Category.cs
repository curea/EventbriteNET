﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System;

namespace EventbriteNET
{
    /// <summary>
    /// Represents an Eventbrite Category <see cref="https://developer.eventbrite.com/docs/category-object/"/>
    /// </summary>
    public class Category : EventbriteObject
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("name_localized")]
        public string NameLocalized { get; set; }
        [JsonPropertyName("short_name")]
        public string ShortName { get; set; }
        [JsonPropertyName("short_name_localized")]
        public string ShortNameLocalized { get; set; }
    }

    /// <summary>
    /// Represents an Eventbrite Subcategory <see cref="https://developer.eventbrite.com/docs/subcategory-object/"/>
    /// </summary>
    public class Subcategory : EventbriteObject
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }
}
